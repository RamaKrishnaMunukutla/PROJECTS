import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-clinet-link',
  templateUrl: './assignment-clinet-link.component.html',
  styleUrls: ['./assignment-clinet-link.component.css']
})
export class AssignmentClinetLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

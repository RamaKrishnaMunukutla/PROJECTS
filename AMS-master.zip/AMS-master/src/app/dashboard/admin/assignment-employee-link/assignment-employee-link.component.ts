import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-employee-link',
  templateUrl: './assignment-employee-link.component.html',
  styleUrls: ['./assignment-employee-link.component.css']
})
export class AssignmentEmployeeLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

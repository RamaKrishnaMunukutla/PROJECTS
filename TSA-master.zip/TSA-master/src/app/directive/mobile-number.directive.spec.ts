import { MobileNumberDirective } from './mobile-number.directive';

describe('MobileNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new MobileNumberDirective();
    expect(directive).toBeTruthy();
  });
});

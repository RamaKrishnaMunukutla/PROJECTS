import { AlphaTestDirective } from './alpha-test.directive';

describe('AlphaTestDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphaTestDirective();
    expect(directive).toBeTruthy();
  });
});

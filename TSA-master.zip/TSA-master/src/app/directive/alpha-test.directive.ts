import { Directive } from '@angular/core';

@Directive({
  selector: '[appAlphaTest]'
})
export class AlphaTestDirective {

  
  
}

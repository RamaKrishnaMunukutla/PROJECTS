package com.ojas.obs.psa;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectInfoApplicationTests {


}

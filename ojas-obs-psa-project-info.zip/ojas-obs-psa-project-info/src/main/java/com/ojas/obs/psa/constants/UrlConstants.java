package com.ojas.obs.psa.constants;

public class UrlConstants {
	public static final String SET = "/set";
	public static final String GET = "/get";
	private UrlConstants() {
		
	}
}

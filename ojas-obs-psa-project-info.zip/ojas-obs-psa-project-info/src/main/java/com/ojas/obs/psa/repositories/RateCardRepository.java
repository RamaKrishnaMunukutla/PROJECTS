package com.ojas.obs.psa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ojas.obs.psa.model.ProjectRatecard;

public interface RateCardRepository extends JpaRepository<ProjectRatecard, Integer>{

}
